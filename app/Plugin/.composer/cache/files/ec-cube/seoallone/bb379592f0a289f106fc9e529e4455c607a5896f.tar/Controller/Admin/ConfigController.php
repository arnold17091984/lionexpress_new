<?php

namespace Plugin\SEOAllOne\Controller\Admin;

use Eccube\Controller\AbstractController;
use Plugin\SEOAllOne\Form\Type\Admin\ConfigType;
use Plugin\SEOAllOne\Repository\ConfigRepository;
use Plugin\SEOAllOne\Util\Util;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Eccube\Common\EccubeConfig;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Eccube\Repository\ProductRepository;
use Eccube\Repository\CategoryRepository;
use Plugin\SEOAllOne\Entity\SEOAllOneProduct;
use Plugin\SEOAllOne\Entity\SEOAllOneCategory;
use Plugin\SEOAllOne\Repository\SEOAllOneProductRepository;
use Plugin\SEOAllOne\Repository\SEOAllOneCategoryRepository;
use Plugin\SEOAllOne\Service\ExportService;
use Doctrine\ORM\Query\ResultSetMapping;
use Eccube\Entity\ExportCsvRow;
use Eccube\Util\CacheUtil;
use Eccube\Form\Type\Admin\CsvImportType;
use Eccube\Entity\Master\CsvType;

class ConfigController extends AbstractController
{
    /**
     * @var ConfigRepository
     */
    protected $configRepository;
    protected $container;
    protected $eccubeConfig;
    protected $exportService;

    /**
     * ConfigController constructor.
     *
     * @param ConfigRepository $configRepository
     */
    public function __construct(ConfigRepository $configRepository, ContainerInterface $container, EccubeConfig $eccubeConfig,
        ProductRepository $productRepository, CategoryRepository $categoryRepository, ExportService $exportService, SEOAllOneProductRepository $SEOAllOneProductRepository, SEOAllOneCategoryRepository $SEOAllOneCategoryRepository)
    {
        $this->configRepository = $configRepository;
        $this->container = $container;
        $this->eccubeConfig = $eccubeConfig;
		$this->productRepository = $productRepository;
        $this->categoryRepository = $categoryRepository;
        $this->exportService = $exportService;
        $this->SEOAllOneProductRepository = $SEOAllOneProductRepository;
        $this->SEOAllOneCategoryRepository = $SEOAllOneCategoryRepository;
    }

    /**
     * @Route("/%eccube_admin_route%/seoallone/config", name="seo_all_one_admin_config")
     * @Template("@SEOAllOne/admin/config.twig")
     */
    public function index(Request $request)
    {
        $Config = $this->configRepository->findOneBy([]);
        $sitemapFlag = $Config->getSitemapFlg();

        //generate miss data
        $sql = "SELECT * FROM plg_seoallone_category where discriminator_type =''";
        $stmt = $this->entityManager->getConnection()->executeQuery($sql);
        $SEOAllOneCategory = $stmt->fetch();
        $sql = "SELECT * FROM plg_seoallone_product where discriminator_type =''";
        $stmt = $this->entityManager->getConnection()->executeQuery($sql);
        $SEOAllOneProduct = $stmt->fetch();
        if ($SEOAllOneCategory && $SEOAllOneCategory['discriminator_type'] == '') {
            $sql = "UPDATE plg_seoallone_category SET discriminator_type = 'seoallonecategory'";
            $stmt = $this->entityManager->getConnection()->executeQuery($sql);
            $stmt->execute([]);
        }
        if ($SEOAllOneProduct && $SEOAllOneProduct['discriminator_type'] == '') {
            $sql = "UPDATE plg_seoallone_product SET discriminator_type = 'seoalloneproduct'";
            $stmt = $this->entityManager->getConnection()->executeQuery($sql);
            $stmt->execute([]);
        }

        $form = $this->createForm(ConfigType::class, $Config);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $Config = $form->getData();
            if ($Config->getSnsFlg() == 0)
            {
                $Config->setFacebookFlg(FALSE);
                $Config->setTwitterFlg(FALSE);
                $Config->setLineFlg(FALSE);
            }
			if(!$Config->getValidPriceMonth()) {
				$Config->setValidPriceMonth(0);
			}
            if($Config->getSitemapFlg() != $sitemapFlag) {
                if($Config->getSitemapFlg() == 0) {
                    $path = $this->eccubeConfig->get('kernel.project_dir') . '/sitemap.xml';
                    if(is_file($path))  
                    {
                        // delete file
                        @chmod($path, 0777);
                        @unlink($path);
                    }
                } else {
                    $Util = new Util($this->container);
                    $Util->generateSitemap($this->container, $this->eccubeConfig);
                }
            }
            $this->entityManager->persist($Config);
            $this->entityManager->flush($Config);
			
			// update products
			/*
			if($Config->getValidPriceFlg()) {
				$em = $this->container->get('doctrine.orm.entity_manager');
				$conn = $em->getConnection();
				
				$configGlobalIdType = (int)$Config->getGlobalIdType();
				$configValidPriceMonth = (int)$Config->getValidPriceMonth();
				
				$query = "SELECT dtb_product.id, plg_seoallone_product.product_id, plg_seoallone_product.global_id_type, plg_seoallone_product.global_id, plg_seoallone_product.valid_price_month ";
				$query.= "FROM dtb_product left join plg_seoallone_product on dtb_product.id=plg_seoallone_product.product_id ";
				$res = $conn->fetchAll($query);
				if ($res) {
					foreach ($res as $item) {
						if (!$item['product_id']){
							$SeoalloneProduct = new SEOAllOneProduct();
							if (!$SeoalloneProduct->getValidPriceMonth()) {
								$Product = $this->productRepository->findOneBy(['id' => $item['id']]);
								$SeoalloneProduct->setProduct($Product);
								$SeoalloneProduct->setGlobalIdType($configGlobalIdType);
								$SeoalloneProduct->setValidPriceMonth($configValidPriceMonth);
								$SeoalloneProduct->setNoindexFlg(0);
								$SeoalloneProduct->setDelFlg($configValidPriceMonth);
								$em->persist($SeoalloneProduct);
								$em->flush($SeoalloneProduct);
							}
						}						
					}
				}
			}
			*/
			
            $this->addSuccess('登録しました。', 'admin');

            return $this->redirectToRoute('seo_all_one_admin_config');
        }

        return [
            'form' => $form->createView(),
            'Config'    => $Config,
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/seoallone/manual", name="seoallone_admin_manual")
     * @Template("@SEOAllOne/admin/manual.twig")
     */
    public function manual(Request $request)
    {
        return [];
    }

    /**
     * 商品CSVの出力.
     *
     * @Route("/%eccube_admin_route%/seoallone/export/category", name="admin_seoallone_export_category", methods={"GET"})
     *
     * @param Request $request
     *
     * @return StreamedResponse
     */

    public function export_category(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);
        
        $response = new StreamedResponse();
        $csvType = $em->getRepository(CsvType::class)->findOneBy(['name' => 'SEOAllOneCategory'])->getId();
        $response->setCallback(function () use ($request, $csvType) {
            
            // CSV種別を元に初期化.
            $this->exportService->initCsvType($csvType);

            // ヘッダ行の出力.
            $this->exportService->exportHeader();

            // 商品データ検索用のクエリビルダを取得.
            $qb = $this->exportService
                ->getCategorySEOQueryBuilder($request);

            // データ行の出力.
            $this->exportService->setExportQueryBuilder($qb);

            $this->exportService->exportData(function ($entity, ExportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $ExportCsvRow = new ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    // 商品データを検索.
                    $ExportCsvRow->setData($csvService->getData($Csv, $entity));

                    $ExportCsvRow->pushData();
                }
                
                // 出力.
                $data = $ExportCsvRow->getRow();
                
                $Category = $entity->getCategory();
                $data[0] =$Category->getId();
                $data[1] =$Category->getName();
                
                $csvService->fputcsv($data);
            });
        });

        $now = new \DateTime();
        $filename = 'SEOAllOneCategory'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        // $response->send();

        log_info('商品CSV出力ファイル名', [$filename]);

        return $response;
    }
   
    /**
      * 商品CSVの出力.
      *
      * @Route("/%eccube_admin_route%/seoallone/export/product", name="admin_seoallone_export_product", methods={"GET"})
      *
      * @param Request $request
      *
      * @return StreamedResponse
      */
   
    public function export_product(Request $request)
    {
        // タイムアウトを無効にする.
        set_time_limit(0);

        // sql loggerを無効にする.
        $em = $this->entityManager;
        $em->getConfiguration()->setSQLLogger(null);
        

        $response = new StreamedResponse();
        $csvType = $em->getRepository(CsvType::class)->findOneBy(['name' => 'SEOAllOneProduct'])->getId();
        $response->setCallback(function () use ($request, $csvType) {

            // CSV種別を元に初期化.
            $this->exportService->initCsvType($csvType);

            // ヘッダ行の出力.
            $this->exportService->exportHeader();

            // 商品データ検索用のクエリビルダを取得.
            $qb = $this->exportService
                ->getProductSEOQueryBuilder($request);

            // データ行の出力.
            $this->exportService->setExportQueryBuilder($qb);

            $this->exportService->exportData(function ($entity, exportService $csvService) use ($request) {
                $Csvs = $csvService->getCsvs();

                $ExportCsvRow = new ExportCsvRow();

                // CSV出力項目と合致するデータを取得.
                foreach ($Csvs as $Csv) {
                    // 商品データを検索.
                    $ExportCsvRow->setData($csvService->getData($Csv, $entity));

                    $ExportCsvRow->pushData();
                }
                
                // 出力.
                $data = $ExportCsvRow->getRow();
                
                $Product = $entity->getProduct();

                $data[0] =$Product->getId();
                $data[1] =$Product->getName();
                
                $csvService->fputcsv($data);
            });
        });

        $now = new \DateTime();
        $filename = 'SEOAllOneProduct'.$now->format('YmdHis').'.csv';
        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename='.$filename);
        // $response->send();

        log_info('商品CSV出力ファイル名', [$filename]);

        return $response;
    }
}
